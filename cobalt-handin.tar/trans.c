/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */
#include <stdio.h>
#include "cachelab.h"

#define BLKSIZE 8
#define HALFSIZE 4

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */


char transpose_submit_desc[] = "Transpose submission";

void transpose_submit(int M, int N, int A[N][M], int B[M][N]) {
    int i, j;
    int blk_i, blk_j;
    int tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
    for (i = 0; i < N; i += 2 * BLKSIZE) {
        if (i + 2 * BLKSIZE <= N) {
            for (j = 0; j < M; j += BLKSIZE) {
                do {
                    if (j + BLKSIZE <= M) {
                        if (i != j || N != M) {//case 1: normal case, optimize for N = M = 64
                            /*
                             * -----
                             * |1|2|
                             * -----
                             * |3|4|
                             * -----
                             *
                             * 1) move 1, 2
                             * 2) transpose 1, 2 in B
                             * 3) move 3 while transposing to B, move 2 in B to 3 in B
                             * 4) transpose and move 4
                             */

                            for (blk_i = 0; blk_i < HALFSIZE; blk_i++)
                                for (blk_j = 0; blk_j < BLKSIZE; blk_j++)
                                    B[j + blk_i][i + blk_j] = A[i + blk_i][j + blk_j];

                            for (blk_i = 0; blk_i < HALFSIZE; blk_i++)
                                for (blk_j = blk_i + 1; blk_j < HALFSIZE; blk_j++) {
                                    tmp0 = B[j + blk_i][i + blk_j];
                                    B[j + blk_i][i + blk_j] = B[j + blk_j][i + blk_i];
                                    B[j + blk_j][i + blk_i] = tmp0;

                                    tmp0 = B[j + blk_i][i + HALFSIZE + blk_j];
                                    B[j + blk_i][i + HALFSIZE + blk_j] = B[j + blk_j][i + HALFSIZE + blk_i];
                                    B[j + blk_j][i + HALFSIZE + blk_i] = tmp0;
                                }
                            for (blk_i = 0; blk_i < HALFSIZE; blk_i++) {
                                tmp0 = A[i + HALFSIZE][j + blk_i];
                                tmp1 = A[i + HALFSIZE + 1][j + blk_i];
                                tmp2 = A[i + HALFSIZE + 2][j + blk_i];
                                tmp3 = A[i + HALFSIZE + 3][j + blk_i];

                                tmp4 = B[j + blk_i][i + HALFSIZE];
                                tmp5 = B[j + blk_i][i + HALFSIZE + 1];
                                tmp6 = B[j + blk_i][i + HALFSIZE + 2];
                                tmp7 = B[j + blk_i][i + HALFSIZE + 3];

                                B[j + blk_i][i + HALFSIZE] = tmp0;
                                B[j + blk_i][i + HALFSIZE + 1] = tmp1;
                                B[j + blk_i][i + HALFSIZE + 2] = tmp2;
                                B[j + blk_i][i + HALFSIZE + 3] = tmp3;

                                B[j + HALFSIZE + blk_i][i] = tmp4;
                                B[j + HALFSIZE + blk_i][i + 1] = tmp5;
                                B[j + HALFSIZE + blk_i][i + 2] = tmp6;
                                B[j + HALFSIZE + blk_i][i + 3] = tmp7;
                            }
                            for (blk_i = HALFSIZE; blk_i < BLKSIZE; blk_i++)
                                for (blk_j = HALFSIZE; blk_j < BLKSIZE; blk_j++)
                                    B[j + blk_j][i + blk_i] = A[i + blk_i][j + blk_j];
                        } else if (i + BLKSIZE < N) {
                            //case 2: diagonal blocks
                            //copy block to adjacent block in array B
                            for (blk_i = 0; blk_i < BLKSIZE; blk_i++)
                                for (blk_j = 0; blk_j < BLKSIZE; blk_j++)
                                    B[i + blk_i][j + blk_j + BLKSIZE] = A[i + blk_i][j + blk_j];
                            //transpose
                            for (blk_j = BLKSIZE - 1; blk_j >= 0; blk_j--)
                                for (blk_i = HALFSIZE; blk_i < BLKSIZE; blk_i++)
                                    B[j + blk_j][i + blk_i] = B[i + blk_i][j + blk_j + BLKSIZE];
                            //copy to target block
                            for (blk_j = 0; blk_j < BLKSIZE; blk_j++)
                                for (blk_i = 0; blk_i < HALFSIZE; blk_i++)
                                    B[j + blk_j][i + blk_i] = B[i + blk_i][j + blk_j + BLKSIZE];

                        } else {
                            //case 3: last diagonal block
                            //copy to target block
                            for (blk_i = 0; blk_i < BLKSIZE; blk_i++) {
                                tmp0 = A[i + blk_i][j];
                                tmp1 = A[i + blk_i][j + 1];
                                tmp2 = A[i + blk_i][j + 2];
                                tmp3 = A[i + blk_i][j + 3];
                                tmp4 = A[i + blk_i][j + 4];
                                tmp5 = A[i + blk_i][j + 5];
                                tmp6 = A[i + blk_i][j + 6];
                                tmp7 = A[i + blk_i][j + 7];
                                B[j][i + blk_i] = tmp0;
                                B[j + 1][i + blk_i] = tmp1;
                                B[j + 2][i + blk_i] = tmp2;
                                B[j + 3][i + blk_i] = tmp3;
                                B[j + 4][i + blk_i] = tmp4;
                                B[j + 5][i + blk_i] = tmp5;
                                B[j + 6][i + blk_i] = tmp6;
                                B[j + 7][i + blk_i] = tmp7;
                            }
                            //transpose
                            for (blk_i = 0; blk_i < BLKSIZE; blk_i++)
                                for (blk_j = blk_i + 1; blk_j < BLKSIZE; blk_j++) {
                                    tmp0 = A[i + blk_i][j + blk_j];
                                    A[i + blk_i][j + blk_j] = B[j + blk_j][i + blk_i];
                                    B[j + blk_j][i + blk_i] = tmp0;
                                }
                        }
                    } else {// j+ BLKSIZE >= M
                        for (blk_j = j; blk_j < M; blk_j++)
                            for (blk_i = 0; blk_i < BLKSIZE; blk_i++)
                                B[blk_j][i + blk_i] = A[i + blk_i][blk_j];
                    }

                    i += BLKSIZE;

                } while ((i / BLKSIZE) % 2 != 0);

                i -= 2 * BLKSIZE;

            }


        } else {// i + 2 * BLKSIZE >= N
            for (j = 0; j < M; j += BLKSIZE) {
                if (j + BLKSIZE <= M) {
                    for (blk_j = 0; blk_j < BLKSIZE; blk_j++)
                        for (blk_i = i; blk_i < N; blk_i++)
                            B[j + blk_j][blk_i] = A[blk_i][j + blk_j];
                } else {
                    for (blk_i = i; blk_i < N; blk_i++)
                        for (blk_j = j; blk_j < M; blk_j++)
                            B[blk_j][blk_i] = A[blk_i][blk_j];
                }
            }
        }
    }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";

void trans(int M, int N, int A[N][M], int B[M][N]) {
    int i, j, tmp;
    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }

    }

}

char transref_desc[] = "referece-MUST REMOVE BEFORE SUBMIT";

void transref(int M, int N, int A[N][M], int B[M][N]) {
    int i, j, k, l;
    int a0, a1, a2, a3, a4, a5, a6, a7;
    //   int SubBLK = 256 / M;
    i = 0;
    while (i + BLKSIZE <= N) {
        j = 0;
        while (j + BLKSIZE <= M) {
            if (i != j) {
                a0 = A[i][j + HALFSIZE];
                a1 = A[i][j + HALFSIZE + 1];
                a2 = A[i][j + HALFSIZE + 2];
                a3 = A[i][j + HALFSIZE + 3];
                a4 = A[i + 1][j + HALFSIZE];
                a5 = A[i + 1][j + HALFSIZE + 1];
                a6 = A[i + 1][j + HALFSIZE + 2];
                a7 = A[i + 1][j + HALFSIZE + 3];
                for (k = 0; k < BLKSIZE; k++) {
                    for (l = 0; l < HALFSIZE; l++) {
                        B[j + l][i + k] = A[i + k][j + l];
                    }
                }
                for (k = BLKSIZE - 1; k >= 2; k--) {
                    for (l = HALFSIZE; l < BLKSIZE; l++) {
                        B[j + l][i + k] = A[i + k][j + l];
                    }
                }
                B[j + HALFSIZE][i] = a0;
                B[j + HALFSIZE + 1][i] = a1;
                B[j + HALFSIZE + 2][i] = a2;
                B[j + HALFSIZE + 3][i] = a3;
                B[j + HALFSIZE][i + 1] = a4;
                B[j + HALFSIZE + 1][i + 1] = a5;
                B[j + HALFSIZE + 2][i + 1] = a6;
                B[j + HALFSIZE + 3][i + 1] = a7;

            } else if (i + BLKSIZE < N) {//diagonal blocks
                for (k = 0; k < BLKSIZE; k++) {
                    for (l = 0; l < BLKSIZE; l++) {
                        B[i + k][j + l + BLKSIZE] = A[i + k][j + l];
                    }
                }
                for (l = BLKSIZE - 1; l >= 0; l--) {
                    for (k = HALFSIZE; k < BLKSIZE; k++) {
                        B[j + l][i + k] = B[i + k][j + l + BLKSIZE];
                    }
                }
                for (l = 0; l < BLKSIZE; l++) {
                    for (k = 0; k < HALFSIZE; k++) {
                        B[j + l][i + k] = B[i + k][j + l + BLKSIZE];
                    }
                }
            } else {

                for (k = 0; k < BLKSIZE; k++) {//first copy them right to B
                    a0 = A[i + k][j + 1];
                    a1 = A[i + k][j + 2];
                    a2 = A[i + k][j + 3];
                    a3 = A[i + k][j + 4];
                    a4 = A[i + k][j + 5];
                    a5 = A[i + k][j + 6];
                    a6 = A[i + k][j + 7];
                    B[i + k][j] = A[i + k][j];
                    B[i + k][j + 1] = a0;
                    B[i + k][j + 2] = a1;
                    B[i + k][j + 3] = a2;
                    B[i + k][j + 4] = a3;
                    B[i + k][j + 5] = a4;
                    B[i + k][j + 6] = a5;
                    B[i + k][j + 7] = a6;
                }
                for (k = BLKSIZE - 1; k >= 0; k--) {//then transpose
                    for (l = k; l >= 0; l--) {
                        a0 = B[i + k][j + l];
                        B[i + k][j + l] = B[j + l][i + k];
                        B[j + l][i + k] = a0;
                    }
                }
            }
            if ((i / BLKSIZE) % 2 == 0) {
                if ((j / BLKSIZE) % 2 == 0)
                    i += BLKSIZE;
                else
                    j += BLKSIZE;
            } else {
                if ((j / BLKSIZE) % 2 == 0)
                    j += BLKSIZE;
                else
                    i -= BLKSIZE;
            }
        }
        i /= BLKSIZE;
        i /= 2;
        i++;
        i *= 2;
        i *= BLKSIZE;
    }
    j = N - (N % BLKSIZE);
    i = M - (M % BLKSIZE);
    for (a1 = 0; a1 < j; a1 += BLKSIZE)
        for (a0 = i; a0 < M; a0++)
            for (k = 0; k < BLKSIZE; k++)
                B[a0][a1 + k] = A[a1 + k][a0];
    for (a0 = 0; a0 < i; a0 += BLKSIZE)
        for (a1 = j; a1 < N; a1++)
            for (k = 0; k < BLKSIZE; k++)
                B[a0 + k][a1] = A[a1][a0 + k];
    for (; i < M; i++)
        for (j = i + 1; j < N; j++)
            B[i][j] = A[j][i];
}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions() {
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc);

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc);

    registerTransFunction(transref, transref_desc);

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N]) {
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

